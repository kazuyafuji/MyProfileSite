<?php


/*--------------------------------------------------------------------------
	
	Script Name    : Responsive Mailform
	Author         : FIRSTSTEP - Motohiro Tani
	Author URL     : https://www.1-firststep.com
	Create Date    : 2014/03/25
	Version        : 8.0.1
	Last Update    : 2021/12/03
	
--------------------------------------------------------------------------*/
